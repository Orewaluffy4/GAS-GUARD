/**
 * @file       BlynkSimpleUipEthernet.h
 * @author     Volodymyr Shymanskyy
 * @license    This project is released under the MIT License (MIT)
 * @copyright  Copyright (c) 2015 Volodymyr Shymanskyy
 * @date       Jan 2015
 * @brief
 *
 */

#ifndef BlynkSimpleUipEthernet_h
#define BlynkSimpleUipEthernet_h

#error "BlynkSimpleUipEthernet.h is deprecated. Please use BlynkSimpleEthernetENC.h"

#endif
